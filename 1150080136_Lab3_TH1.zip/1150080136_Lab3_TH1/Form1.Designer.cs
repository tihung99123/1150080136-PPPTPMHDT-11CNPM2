﻿namespace _1150080136_Lab3_TH1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.picIcon = new System.Windows.Forms.PictureBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblMenu = new System.Windows.Forms.Label();
            this.tblMenu = new System.Windows.Forms.TableLayoutPanel();
            this.btnComChienTrung = new System.Windows.Forms.Button();
            this.btnBanhMyOpLa = new System.Windows.Forms.Button();
            this.btnCoca = new System.Windows.Forms.Button();
            this.btnLipton = new System.Windows.Forms.Button();
            this.btnOcRangMuoi = new System.Windows.Forms.Button();
            this.btnKhoaiTayChien = new System.Windows.Forms.Button();
            this.btn7Up = new System.Windows.Forms.Button();
            this.btnCam = new System.Windows.Forms.Button();
            this.btnMyXaoHaiSan = new System.Windows.Forms.Button();
            this.btnCaVienChien = new System.Windows.Forms.Button();
            this.btnPepsi = new System.Windows.Forms.Button();
            this.btnCafe = new System.Windows.Forms.Button();
            this.btnBugerBoNuong = new System.Windows.Forms.Button();
            this.btnDuiGaRan = new System.Windows.Forms.Button();
            this.btnBunBoHue = new System.Windows.Forms.Button();
            this.pnlControls = new System.Windows.Forms.Panel();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblTable = new System.Windows.Forms.Label();
            this.cmbTables = new System.Windows.Forms.ComboBox();
            this.btnOrder = new System.Windows.Forms.Button();
            this.lvOrder = new System.Windows.Forms.ListView();
            this.colMon = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colSoLuong = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pnlHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picIcon)).BeginInit();
            this.tblMenu.SuspendLayout();
            this.pnlControls.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlHeader
            // 
            this.pnlHeader.BackColor = System.Drawing.Color.Green;
            this.pnlHeader.Controls.Add(this.lblTitle);
            this.pnlHeader.Location = new System.Drawing.Point(86, 0);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(364, 80);
            this.pnlHeader.TabIndex = 0;
            // 
            // picIcon
            // 
            this.picIcon.BackColor = System.Drawing.Color.Orange;
            this.picIcon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picIcon.Location = new System.Drawing.Point(20, 12);
            this.picIcon.Name = "picIcon";
            this.picIcon.Size = new System.Drawing.Size(50, 50);
            this.picIcon.TabIndex = 0;
            this.picIcon.TabStop = false;
            // 
            // lblTitle
            // 
            this.lblTitle.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(14, 25);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(350, 30);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "Quán ăn nhanh Quốc Hưng";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblTitle.Click += new System.EventHandler(this.lblTitle_Click);
            // 
            // lblMenu
            // 
            this.lblMenu.AutoSize = true;
            this.lblMenu.Location = new System.Drawing.Point(20, 90);
            this.lblMenu.Name = "lblMenu";
            this.lblMenu.Size = new System.Drawing.Size(100, 13);
            this.lblMenu.TabIndex = 1;
            this.lblMenu.Text = "Danh sách món ăn:";
            // 
            // tblMenu
            // 
            this.tblMenu.ColumnCount = 4;
            this.tblMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblMenu.Controls.Add(this.btnComChienTrung, 0, 0);
            this.tblMenu.Controls.Add(this.btnBanhMyOpLa, 1, 0);
            this.tblMenu.Controls.Add(this.btnCoca, 2, 0);
            this.tblMenu.Controls.Add(this.btnLipton, 3, 0);
            this.tblMenu.Controls.Add(this.btnOcRangMuoi, 0, 1);
            this.tblMenu.Controls.Add(this.btnKhoaiTayChien, 1, 1);
            this.tblMenu.Controls.Add(this.btn7Up, 2, 1);
            this.tblMenu.Controls.Add(this.btnCam, 3, 1);
            this.tblMenu.Controls.Add(this.btnMyXaoHaiSan, 0, 2);
            this.tblMenu.Controls.Add(this.btnCaVienChien, 1, 2);
            this.tblMenu.Controls.Add(this.btnPepsi, 2, 2);
            this.tblMenu.Controls.Add(this.btnCafe, 3, 2);
            this.tblMenu.Controls.Add(this.btnBugerBoNuong, 0, 3);
            this.tblMenu.Controls.Add(this.btnDuiGaRan, 1, 3);
            this.tblMenu.Controls.Add(this.btnBunBoHue, 2, 3);
            this.tblMenu.Location = new System.Drawing.Point(20, 115);
            this.tblMenu.Name = "tblMenu";
            this.tblMenu.RowCount = 4;
            this.tblMenu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblMenu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblMenu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblMenu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblMenu.Size = new System.Drawing.Size(410, 140);
            this.tblMenu.TabIndex = 2;
            // 
            // btnComChienTrung
            // 
            this.btnComChienTrung.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnComChienTrung.Font = new System.Drawing.Font("Arial", 8F);
            this.btnComChienTrung.Location = new System.Drawing.Point(2, 2);
            this.btnComChienTrung.Margin = new System.Windows.Forms.Padding(2);
            this.btnComChienTrung.Name = "btnComChienTrung";
            this.btnComChienTrung.Size = new System.Drawing.Size(98, 31);
            this.btnComChienTrung.TabIndex = 0;
            this.btnComChienTrung.Text = "Cơm chiên trứng";
            this.btnComChienTrung.UseVisualStyleBackColor = true;
            this.btnComChienTrung.Click += new System.EventHandler(this.MenuButton_Click);
            // 
            // btnBanhMyOpLa
            // 
            this.btnBanhMyOpLa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnBanhMyOpLa.Font = new System.Drawing.Font("Arial", 8F);
            this.btnBanhMyOpLa.Location = new System.Drawing.Point(104, 2);
            this.btnBanhMyOpLa.Margin = new System.Windows.Forms.Padding(2);
            this.btnBanhMyOpLa.Name = "btnBanhMyOpLa";
            this.btnBanhMyOpLa.Size = new System.Drawing.Size(98, 31);
            this.btnBanhMyOpLa.TabIndex = 1;
            this.btnBanhMyOpLa.Text = "Bánh mỳ ốp la";
            this.btnBanhMyOpLa.UseVisualStyleBackColor = true;
            this.btnBanhMyOpLa.Click += new System.EventHandler(this.MenuButton_Click);
            // 
            // btnCoca
            // 
            this.btnCoca.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnCoca.Font = new System.Drawing.Font("Arial", 8F);
            this.btnCoca.Location = new System.Drawing.Point(206, 2);
            this.btnCoca.Margin = new System.Windows.Forms.Padding(2);
            this.btnCoca.Name = "btnCoca";
            this.btnCoca.Size = new System.Drawing.Size(98, 31);
            this.btnCoca.TabIndex = 2;
            this.btnCoca.Text = "Coca";
            this.btnCoca.UseVisualStyleBackColor = true;
            this.btnCoca.Click += new System.EventHandler(this.MenuButton_Click);
            // 
            // btnLipton
            // 
            this.btnLipton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnLipton.Font = new System.Drawing.Font("Arial", 8F);
            this.btnLipton.Location = new System.Drawing.Point(308, 2);
            this.btnLipton.Margin = new System.Windows.Forms.Padding(2);
            this.btnLipton.Name = "btnLipton";
            this.btnLipton.Size = new System.Drawing.Size(100, 31);
            this.btnLipton.TabIndex = 3;
            this.btnLipton.Text = "Lipton";
            this.btnLipton.UseVisualStyleBackColor = true;
            this.btnLipton.Click += new System.EventHandler(this.MenuButton_Click);
            // 
            // btnOcRangMuoi
            // 
            this.btnOcRangMuoi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnOcRangMuoi.Font = new System.Drawing.Font("Arial", 8F);
            this.btnOcRangMuoi.Location = new System.Drawing.Point(2, 37);
            this.btnOcRangMuoi.Margin = new System.Windows.Forms.Padding(2);
            this.btnOcRangMuoi.Name = "btnOcRangMuoi";
            this.btnOcRangMuoi.Size = new System.Drawing.Size(98, 31);
            this.btnOcRangMuoi.TabIndex = 4;
            this.btnOcRangMuoi.Text = "Ốc rang muối";
            this.btnOcRangMuoi.UseVisualStyleBackColor = true;
            this.btnOcRangMuoi.Click += new System.EventHandler(this.MenuButton_Click);
            // 
            // btnKhoaiTayChien
            // 
            this.btnKhoaiTayChien.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnKhoaiTayChien.Font = new System.Drawing.Font("Arial", 8F);
            this.btnKhoaiTayChien.Location = new System.Drawing.Point(104, 37);
            this.btnKhoaiTayChien.Margin = new System.Windows.Forms.Padding(2);
            this.btnKhoaiTayChien.Name = "btnKhoaiTayChien";
            this.btnKhoaiTayChien.Size = new System.Drawing.Size(98, 31);
            this.btnKhoaiTayChien.TabIndex = 5;
            this.btnKhoaiTayChien.Text = "Khoai tây chiên";
            this.btnKhoaiTayChien.UseVisualStyleBackColor = true;
            this.btnKhoaiTayChien.Click += new System.EventHandler(this.MenuButton_Click);
            // 
            // btn7Up
            // 
            this.btn7Up.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn7Up.Font = new System.Drawing.Font("Arial", 8F);
            this.btn7Up.Location = new System.Drawing.Point(206, 37);
            this.btn7Up.Margin = new System.Windows.Forms.Padding(2);
            this.btn7Up.Name = "btn7Up";
            this.btn7Up.Size = new System.Drawing.Size(98, 31);
            this.btn7Up.TabIndex = 6;
            this.btn7Up.Text = "7 up";
            this.btn7Up.UseVisualStyleBackColor = true;
            this.btn7Up.Click += new System.EventHandler(this.MenuButton_Click);
            // 
            // btnCam
            // 
            this.btnCam.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnCam.Font = new System.Drawing.Font("Arial", 8F);
            this.btnCam.Location = new System.Drawing.Point(308, 37);
            this.btnCam.Margin = new System.Windows.Forms.Padding(2);
            this.btnCam.Name = "btnCam";
            this.btnCam.Size = new System.Drawing.Size(100, 31);
            this.btnCam.TabIndex = 7;
            this.btnCam.Text = "Cam";
            this.btnCam.UseVisualStyleBackColor = true;
            this.btnCam.Click += new System.EventHandler(this.MenuButton_Click);
            // 
            // btnMyXaoHaiSan
            // 
            this.btnMyXaoHaiSan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMyXaoHaiSan.Font = new System.Drawing.Font("Arial", 8F);
            this.btnMyXaoHaiSan.Location = new System.Drawing.Point(2, 72);
            this.btnMyXaoHaiSan.Margin = new System.Windows.Forms.Padding(2);
            this.btnMyXaoHaiSan.Name = "btnMyXaoHaiSan";
            this.btnMyXaoHaiSan.Size = new System.Drawing.Size(98, 31);
            this.btnMyXaoHaiSan.TabIndex = 8;
            this.btnMyXaoHaiSan.Text = "Mỳ xào hải sản";
            this.btnMyXaoHaiSan.UseVisualStyleBackColor = true;
            this.btnMyXaoHaiSan.Click += new System.EventHandler(this.MenuButton_Click);
            // 
            // btnCaVienChien
            // 
            this.btnCaVienChien.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnCaVienChien.Font = new System.Drawing.Font("Arial", 8F);
            this.btnCaVienChien.Location = new System.Drawing.Point(104, 72);
            this.btnCaVienChien.Margin = new System.Windows.Forms.Padding(2);
            this.btnCaVienChien.Name = "btnCaVienChien";
            this.btnCaVienChien.Size = new System.Drawing.Size(98, 31);
            this.btnCaVienChien.TabIndex = 9;
            this.btnCaVienChien.Text = "Cá viên chiên";
            this.btnCaVienChien.UseVisualStyleBackColor = true;
            this.btnCaVienChien.Click += new System.EventHandler(this.MenuButton_Click);
            // 
            // btnPepsi
            // 
            this.btnPepsi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnPepsi.Font = new System.Drawing.Font("Arial", 8F);
            this.btnPepsi.Location = new System.Drawing.Point(206, 72);
            this.btnPepsi.Margin = new System.Windows.Forms.Padding(2);
            this.btnPepsi.Name = "btnPepsi";
            this.btnPepsi.Size = new System.Drawing.Size(98, 31);
            this.btnPepsi.TabIndex = 10;
            this.btnPepsi.Text = "Pepsi";
            this.btnPepsi.UseVisualStyleBackColor = true;
            this.btnPepsi.Click += new System.EventHandler(this.MenuButton_Click);
            // 
            // btnCafe
            // 
            this.btnCafe.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnCafe.Font = new System.Drawing.Font("Arial", 8F);
            this.btnCafe.Location = new System.Drawing.Point(308, 72);
            this.btnCafe.Margin = new System.Windows.Forms.Padding(2);
            this.btnCafe.Name = "btnCafe";
            this.btnCafe.Size = new System.Drawing.Size(100, 31);
            this.btnCafe.TabIndex = 11;
            this.btnCafe.Text = "Cafe";
            this.btnCafe.UseVisualStyleBackColor = true;
            this.btnCafe.Click += new System.EventHandler(this.MenuButton_Click);
            // 
            // btnBugerBoNuong
            // 
            this.btnBugerBoNuong.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnBugerBoNuong.Font = new System.Drawing.Font("Arial", 8F);
            this.btnBugerBoNuong.Location = new System.Drawing.Point(2, 107);
            this.btnBugerBoNuong.Margin = new System.Windows.Forms.Padding(2);
            this.btnBugerBoNuong.Name = "btnBugerBoNuong";
            this.btnBugerBoNuong.Size = new System.Drawing.Size(98, 31);
            this.btnBugerBoNuong.TabIndex = 12;
            this.btnBugerBoNuong.Text = "Buger bò nướng";
            this.btnBugerBoNuong.UseVisualStyleBackColor = true;
            this.btnBugerBoNuong.Click += new System.EventHandler(this.MenuButton_Click);
            // 
            // btnDuiGaRan
            // 
            this.btnDuiGaRan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDuiGaRan.Font = new System.Drawing.Font("Arial", 8F);
            this.btnDuiGaRan.Location = new System.Drawing.Point(104, 107);
            this.btnDuiGaRan.Margin = new System.Windows.Forms.Padding(2);
            this.btnDuiGaRan.Name = "btnDuiGaRan";
            this.btnDuiGaRan.Size = new System.Drawing.Size(98, 31);
            this.btnDuiGaRan.TabIndex = 13;
            this.btnDuiGaRan.Text = "Đùi gà rán";
            this.btnDuiGaRan.UseVisualStyleBackColor = true;
            this.btnDuiGaRan.Click += new System.EventHandler(this.MenuButton_Click);
            // 
            // btnBunBoHue
            // 
            this.btnBunBoHue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnBunBoHue.Font = new System.Drawing.Font("Arial", 8F);
            this.btnBunBoHue.Location = new System.Drawing.Point(206, 107);
            this.btnBunBoHue.Margin = new System.Windows.Forms.Padding(2);
            this.btnBunBoHue.Name = "btnBunBoHue";
            this.btnBunBoHue.Size = new System.Drawing.Size(98, 31);
            this.btnBunBoHue.TabIndex = 14;
            this.btnBunBoHue.Text = "Bún bò Huế";
            this.btnBunBoHue.UseVisualStyleBackColor = true;
            this.btnBunBoHue.Click += new System.EventHandler(this.MenuButton_Click);
            // 
            // pnlControls
            // 
            this.pnlControls.Controls.Add(this.btnClear);
            this.pnlControls.Controls.Add(this.lblTable);
            this.pnlControls.Controls.Add(this.cmbTables);
            this.pnlControls.Controls.Add(this.btnOrder);
            this.pnlControls.Location = new System.Drawing.Point(20, 265);
            this.pnlControls.Name = "pnlControls";
            this.pnlControls.Size = new System.Drawing.Size(410, 35);
            this.pnlControls.TabIndex = 3;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(0, 2);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(60, 30);
            this.btnClear.TabIndex = 0;
            this.btnClear.Text = "Xóa";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // lblTable
            // 
            this.lblTable.AutoSize = true;
            this.lblTable.Location = new System.Drawing.Point(80, 8);
            this.lblTable.Name = "lblTable";
            this.lblTable.Size = new System.Drawing.Size(56, 13);
            this.lblTable.TabIndex = 1;
            this.lblTable.Text = "Chọn bàn:";
            // 
            // cmbTables
            // 
            this.cmbTables.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTables.FormattingEnabled = true;
            this.cmbTables.Items.AddRange(new object[] {
            "Bàn 1",
            "Bàn 2",
            "Bàn 3",
            "Bàn 4",
            "Bàn 5",
            "Bàn 6",
            "Bàn 7",
            "Bàn 8",
            "Bàn 9",
            "Bàn 10"});
            this.cmbTables.Location = new System.Drawing.Point(150, 5);
            this.cmbTables.Name = "cmbTables";
            this.cmbTables.Size = new System.Drawing.Size(150, 21);
            this.cmbTables.TabIndex = 2;
            // 
            // btnOrder
            // 
            this.btnOrder.Location = new System.Drawing.Point(320, 2);
            this.btnOrder.Name = "btnOrder";
            this.btnOrder.Size = new System.Drawing.Size(80, 30);
            this.btnOrder.TabIndex = 3;
            this.btnOrder.Text = "Order";
            this.btnOrder.UseVisualStyleBackColor = true;
            this.btnOrder.Click += new System.EventHandler(this.BtnOrder_Click);
            // 
            // lvOrder
            // 
            this.lvOrder.BackColor = System.Drawing.Color.LightGray;
            this.lvOrder.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colMon,
            this.colSoLuong});
            this.lvOrder.FullRowSelect = true;
            this.lvOrder.GridLines = true;
            this.lvOrder.HideSelection = false;
            this.lvOrder.Location = new System.Drawing.Point(20, 310);
            this.lvOrder.Name = "lvOrder";
            this.lvOrder.Size = new System.Drawing.Size(410, 170);
            this.lvOrder.TabIndex = 4;
            this.lvOrder.UseCompatibleStateImageBehavior = false;
            this.lvOrder.View = System.Windows.Forms.View.Details;
            // 
            // colMon
            // 
            this.colMon.Text = "Món";
            this.colMon.Width = 280;
            // 
            // colSoLuong
            // 
            this.colSoLuong.Text = "Số lượng";
            this.colSoLuong.Width = 120;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(450, 500);
            this.Controls.Add(this.picIcon);
            this.Controls.Add(this.lvOrder);
            this.Controls.Add(this.pnlControls);
            this.Controls.Add(this.tblMenu);
            this.Controls.Add(this.lblMenu);
            this.Controls.Add(this.pnlHeader);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.pnlHeader.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picIcon)).EndInit();
            this.tblMenu.ResumeLayout(false);
            this.pnlControls.ResumeLayout(false);
            this.pnlControls.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.PictureBox picIcon;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblMenu;
        private System.Windows.Forms.TableLayoutPanel tblMenu;
        private System.Windows.Forms.Button btnComChienTrung;
        private System.Windows.Forms.Button btnBanhMyOpLa;
        private System.Windows.Forms.Button btnCoca;
        private System.Windows.Forms.Button btnLipton;
        private System.Windows.Forms.Button btnOcRangMuoi;
        private System.Windows.Forms.Button btnKhoaiTayChien;
        private System.Windows.Forms.Button btn7Up;
        private System.Windows.Forms.Button btnCam;
        private System.Windows.Forms.Button btnMyXaoHaiSan;
        private System.Windows.Forms.Button btnCaVienChien;
        private System.Windows.Forms.Button btnPepsi;
        private System.Windows.Forms.Button btnCafe;
        private System.Windows.Forms.Button btnBugerBoNuong;
        private System.Windows.Forms.Button btnDuiGaRan;
        private System.Windows.Forms.Button btnBunBoHue;
        private System.Windows.Forms.Panel pnlControls;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblTable;
        private System.Windows.Forms.ComboBox cmbTables;
        private System.Windows.Forms.Button btnOrder;
        private System.Windows.Forms.ListView lvOrder;
        private System.Windows.Forms.ColumnHeader colMon;
        private System.Windows.Forms.ColumnHeader colSoLuong;
    }
}

