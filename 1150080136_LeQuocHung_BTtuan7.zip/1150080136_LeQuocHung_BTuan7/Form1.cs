﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 1150080136_LeQuocHung_BTuan7
{
    public partial class Form1 : Form
    {
        string strCon = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Administrator\source\repos\1150080136_LeQuocHung_BTuan7\1150080136_LeQuocHung_BTuan7\Database1.mdf"";Integrated Security=True";
        SqlConnection sqlCon = null;

        // 🟣 Các control nhập liệu
        TextBox txtMaSV, txtTenSV, txtQueQuan, txtMaLop;
        ComboBox cbGioiTinh;
        DateTimePicker dtpNgaySinh;
        Button btnThem, btnThem_Para, btnSua, btnSua_Para, btnXoa, btnXoa_Para;
        ListView lvSinhVien;
        string maSVChon = "";

        public Form1()
        {
            MoKetNoi();
            InitializeComponent();
            TaoGiaoDien();
            HienThiDanhSach();
        }

        private void MoKetNoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        private void TaoGiaoDien()
        {
            this.Text = "Quản lý sinh viên - Thêm / Sửa / Xóa (Có và Không Parameter)";
            this.Size = new Size(850, 650);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Input
            Label lblMaSV = new Label() { Text = "Mã SV:", Location = new Point(30, 30), AutoSize = true };
            txtMaSV = new TextBox() { Location = new Point(150, 25), Width = 250 };

            Label lblTenSV = new Label() { Text = "Tên SV:", Location = new Point(30, 70), AutoSize = true };
            txtTenSV = new TextBox() { Location = new Point(150, 65), Width = 250 };

            Label lblGioiTinh = new Label() { Text = "Giới tính:", Location = new Point(30, 110), AutoSize = true };
            cbGioiTinh = new ComboBox() { Location = new Point(150, 105), Width = 250 };
            cbGioiTinh.Items.Add("Nam");
            cbGioiTinh.Items.Add("Nữ");

            Label lblNgaySinh = new Label() { Text = "Ngày sinh:", Location = new Point(30, 150), AutoSize = true };
            dtpNgaySinh = new DateTimePicker() { Location = new Point(150, 145), Width = 250 };

            Label lblQueQuan = new Label() { Text = "Quê quán:", Location = new Point(30, 190), AutoSize = true };
            txtQueQuan = new TextBox() { Location = new Point(150, 185), Width = 250 };

            Label lblMaLop = new Label() { Text = "Mã lớp:", Location = new Point(30, 230), AutoSize = true };
            txtMaLop = new TextBox() { Location = new Point(150, 225), Width = 250 };

            // Nút
            btnThem = new Button() { Text = "Thêm (No Para)", Location = new Point(30, 280), Width = 150, Height = 40 };
            btnThem.Click += btnThem_Click;

            btnThem_Para = new Button() { Text = "Thêm (Para)", Location = new Point(200, 280), Width = 150, Height = 40 };
            btnThem_Para.Click += btnThem_Para_Click;

            btnSua = new Button() { Text = "Sửa (No Para)", Location = new Point(370, 280), Width = 120, Height = 40 };
            btnSua.Click += btnSua_Click;

            btnSua_Para = new Button() { Text = "Sửa (Para)", Location = new Point(510, 280), Width = 120, Height = 40 };
            btnSua_Para.Click += btnSua_Para_Click;

            btnXoa = new Button() { Text = "Xóa (No Para)", Location = new Point(640, 280), Width = 120, Height = 40 };
            btnXoa.Click += btnXoa_Click;

            btnXoa_Para = new Button() { Text = "Xóa (Para)", Location = new Point(640, 330), Width = 120, Height = 40 };
            btnXoa_Para.Click += btnXoa_Para_Click;

            // ListView
            lvSinhVien = new ListView();
            lvSinhVien.Location = new Point(30, 380);
            lvSinhVien.Size = new Size(760, 230);
            lvSinhVien.View = View.Details;
            lvSinhVien.FullRowSelect = true;
            lvSinhVien.GridLines = true;

            lvSinhVien.Columns.Add("Mã SV", 100);
            lvSinhVien.Columns.Add("Tên SV", 150);
            lvSinhVien.Columns.Add("Giới tính", 100);
            lvSinhVien.Columns.Add("Ngày sinh", 120);
            lvSinhVien.Columns.Add("Quê quán", 150);
            lvSinhVien.Columns.Add("Mã lớp", 100);

            lvSinhVien.SelectedIndexChanged += LvSinhVien_SelectedIndexChanged;

            this.Controls.Add(lblMaSV);
            this.Controls.Add(txtMaSV);
            this.Controls.Add(lblTenSV);
            this.Controls.Add(txtTenSV);
            this.Controls.Add(lblGioiTinh);
            this.Controls.Add(cbGioiTinh);
            this.Controls.Add(lblNgaySinh);
            this.Controls.Add(dtpNgaySinh);
            this.Controls.Add(lblQueQuan);
            this.Controls.Add(txtQueQuan);
            this.Controls.Add(lblMaLop);
            this.Controls.Add(txtMaLop);
            this.Controls.Add(btnThem);
            this.Controls.Add(btnThem_Para);
            this.Controls.Add(btnSua);
            this.Controls.Add(btnSua_Para);
            this.Controls.Add(btnXoa);
            this.Controls.Add(btnXoa_Para);
            this.Controls.Add(lvSinhVien);
        }

        private void LvSinhVien_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvSinhVien.SelectedItems.Count == 0) return;
            var item = lvSinhVien.SelectedItems[0];

            maSVChon = item.SubItems[0].Text;
            txtMaSV.Text = item.SubItems[0].Text;
            txtTenSV.Text = item.SubItems[1].Text;
            cbGioiTinh.Text = item.SubItems[2].Text;
            DateTime dateValue;
            if (DateTime.TryParse(item.SubItems[3].Text, out dateValue) &&
                dateValue >= dtpNgaySinh.MinDate && dateValue <= dtpNgaySinh.MaxDate)
            {
                dtpNgaySinh.Value = dateValue;
            }
            else
            {
                dtpNgaySinh.Value = DateTime.Now;
            }
            txtQueQuan.Text = item.SubItems[4].Text;
            txtMaLop.Text = item.SubItems[5].Text;
        }

        // 🟡 Thêm KHÔNG parameter
        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();
                string sql = $"INSERT INTO SinhVien VALUES ('{txtMaSV.Text}', N'{txtTenSV.Text}', N'{cbGioiTinh.Text}', '{dtpNgaySinh.Value:yyyy/MM/dd}', N'{txtQueQuan.Text}', '{txtMaLop.Text}')";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Thêm thành công (No Para)!");
                DongKetNoi();
                HienThiDanhSach();
            }
            catch (Exception ex) { MessageBox.Show("Lỗi thêm: " + ex.Message); }
        }

        // 🟢 Thêm CÓ parameter
        private void btnThem_Para_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();
                SqlCommand cmd = new SqlCommand(
                    "INSERT INTO SinhVien (MaSV, TenSV, GioiTinh, NgaySinh, QueQuan, MaLop) VALUES (@MaSV, @TenSV, @GioiTinh, @NgaySinh, @QueQuan, @MaLop)", sqlCon);
                cmd.Parameters.AddWithValue("@MaSV", txtMaSV.Text.Trim());
                cmd.Parameters.AddWithValue("@TenSV", txtTenSV.Text.Trim());
                cmd.Parameters.AddWithValue("@GioiTinh", cbGioiTinh.Text.Trim());
                cmd.Parameters.AddWithValue("@NgaySinh", dtpNgaySinh.Value);
                cmd.Parameters.AddWithValue("@QueQuan", txtQueQuan.Text.Trim());
                cmd.Parameters.AddWithValue("@MaLop", txtMaLop.Text.Trim());
                cmd.ExecuteNonQuery();
                MessageBox.Show("Thêm thành công (Para)!");
                DongKetNoi();
                HienThiDanhSach();
            }
            catch (Exception ex) { MessageBox.Show("Lỗi thêm: " + ex.Message); }
        }

        // 🛠️ SỬA KHÔNG parameter
        private void btnSua_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(maSVChon)) { MessageBox.Show("Chọn sinh viên để sửa!"); return; }
            try
            {
                MoKetNoi();
                string sql = $"UPDATE SinhVien SET TenSV=N'{txtTenSV.Text}', GioiTinh=N'{cbGioiTinh.Text}', NgaySinh='{dtpNgaySinh.Value:yyyy/MM/dd}', QueQuan=N'{txtQueQuan.Text}', MaLop='{txtMaLop.Text}' WHERE MaSV='{maSVChon}'";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Sửa thành công (No Para)!");
                DongKetNoi();
                HienThiDanhSach();
            }
            catch (Exception ex) { MessageBox.Show("Lỗi sửa: " + ex.Message); }
        }

        // 🛠️ SỬA CÓ parameter
        private void btnSua_Para_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(maSVChon)) { MessageBox.Show("Chọn sinh viên để sửa!"); return; }
            try
            {
                MoKetNoi();
                SqlCommand cmd = new SqlCommand(
                    "UPDATE SinhVien SET TenSV=@TenSV, GioiTinh=@GioiTinh, NgaySinh=@NgaySinh, QueQuan=@QueQuan, MaLop=@MaLop WHERE MaSV=@MaSV",
                    sqlCon);
                cmd.Parameters.AddWithValue("@MaSV", maSVChon);
                cmd.Parameters.AddWithValue("@TenSV", txtTenSV.Text.Trim());
                cmd.Parameters.AddWithValue("@GioiTinh", cbGioiTinh.Text.Trim());
                cmd.Parameters.AddWithValue("@NgaySinh", dtpNgaySinh.Value);
                cmd.Parameters.AddWithValue("@QueQuan", txtQueQuan.Text.Trim());
                cmd.Parameters.AddWithValue("@MaLop", txtMaLop.Text.Trim());
                cmd.ExecuteNonQuery();
                MessageBox.Show("Sửa thành công (Para)!");
                DongKetNoi();
                HienThiDanhSach();
            }
            catch (Exception ex) { MessageBox.Show("Lỗi sửa: " + ex.Message); }
        }

        // 🗑️ XÓA KHÔNG parameter
        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(maSVChon)) { MessageBox.Show("Chọn sinh viên để xóa!"); return; }
            if (MessageBox.Show($"Xóa sinh viên {maSVChon}?", "Xác nhận", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    MoKetNoi();
                    string sql = $"DELETE FROM SinhVien WHERE MaSV='{maSVChon}'";
                    SqlCommand cmd = new SqlCommand(sql, sqlCon);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Xóa thành công (No Para)!");
                    DongKetNoi();
                    HienThiDanhSach();
                }
                catch (Exception ex) { MessageBox.Show("Lỗi xóa: " + ex.Message); }
            }
        }

        // 🗑️ XÓA CÓ parameter
        private void btnXoa_Para_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(maSVChon)) { MessageBox.Show("Chọn sinh viên để xóa!"); return; }
            if (MessageBox.Show($"Xóa sinh viên {maSVChon}?", "Xác nhận", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    MoKetNoi();
                    SqlCommand cmd = new SqlCommand("DELETE FROM SinhVien WHERE MaSV=@MaSV", sqlCon);
                    cmd.Parameters.AddWithValue("@MaSV", maSVChon);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Xóa thành công (Para)!");
                    DongKetNoi();
                    HienThiDanhSach();
                }
                catch (Exception ex) { MessageBox.Show("Lỗi xóa: " + ex.Message); }
            }
        }

        private void HienThiDanhSach()
        {
            try
            {
                MoKetNoi();
                SqlCommand cmd = new SqlCommand("SELECT * FROM SinhVien", sqlCon);
                SqlDataReader reader = cmd.ExecuteReader();

                lvSinhVien.Items.Clear();
                while (reader.Read())
                {
                    string maSV = reader[0].ToString();
                    string tenSV = reader[1].ToString();
                    string gioiTinh = reader[2].ToString();
                    string ngaySinh = Convert.ToDateTime(reader[3]).ToString("dd/MM/yyyy");
                    string queQuan = reader[4].ToString();
                    string maLop = reader[5].ToString();

                    ListViewItem lvi = new ListViewItem(maSV);
                    lvi.SubItems.Add(tenSV);
                    lvi.SubItems.Add(gioiTinh);
                    lvi.SubItems.Add(ngaySinh);
                    lvi.SubItems.Add(queQuan);
                    lvi.SubItems.Add(maLop);

                    lvSinhVien.Items.Add(lvi);
                }

                reader.Close();
                DongKetNoi();
                ClearInput();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi hiển thị dữ liệu: " + ex.Message);
            }
        }

        private void ClearInput()
        {
            txtMaSV.Text = "";
            txtTenSV.Text = "";
            cbGioiTinh.Text = "";
            dtpNgaySinh.Value = DateTime.Now;
            txtQueQuan.Text = "";
            txtMaLop.Text = "";
            maSVChon = "";
        }
    }
}
