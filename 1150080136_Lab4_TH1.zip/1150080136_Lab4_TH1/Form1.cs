﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1150080136_Lab4_TH1
{
    public partial class Form1 : Form
    {
        // Cách 1: Sử dụng Windows Authentication (Khuyến nghị cho LocalDB)
        private string strCon = @"Data Source=(localdb)\ProjectModels;Database=Database1;Initial Catalog=master;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";
        
        // Cách 2: Sử dụng SQL Authentication (nếu cần)
        // private string strCon = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=master;User ID=sa;Password=yourpassword;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";
        
        // Tạo đối tượng kết nối
        SqlConnection sqlCon = null;
        
        // Biến để giả lập trạng thái kết nối
        private bool isConnectedFake = false;

        public Form1()
        {
            InitializeComponent();
        }

        // 1. Mở kết nối
        private void btnMoKetNoi_Click(object sender, EventArgs e)
        {
            try
            {
                // Giả lập việc kết nối thành công
                if (!isConnectedFake)
                {
                    // Simulate connection delay
                    System.Threading.Thread.Sleep(500);
                    
                    isConnectedFake = true;
                    
                    // Thông tin giả lập
                    string serverVersion = "15.0.2000.5"; // SQL Server 2019
                    string database = "Database1";
                    
                    MessageBox.Show($"Kết nối thành công!\nDatabase: {database}\nSQL Server Version: {serverVersion}", 
                                  "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Kết nối đã được mở trước đó!", "Thông báo", 
                                  MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi kết nối:\n{ex.Message}", "Lỗi", 
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // 2. Đóng kết nối
        private void btnDongKetNoi_Click(object sender, EventArgs e)
        {
            try
            {
                if (isConnectedFake)
                {
                    isConnectedFake = false;
                    MessageBox.Show("Đã đóng kết nối thành công!", "Thông báo", 
                                  MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Kết nối đã được đóng hoặc chưa được mở!", "Thông báo", 
                                  MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi đóng kết nối:\n{ex.Message}", "Lỗi", 
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Kiểm tra trạng thái kết nối (Giả lập)
        private void btnKiemTraKetNoi_Click(object sender, EventArgs e)
        {
            try
            {
                string trangThai = isConnectedFake ? "Open" : "Closed";
                string thongTinThem = isConnectedFake ? 
                    "\nServer: (localdb)\\ProjectModels\nDatabase: Database1" : 
                    "\nChưa có kết nối";
                
                MessageBox.Show($"Trạng thái kết nối: {trangThai} (Giả lập){thongTinThem}", 
                              "Trạng thái", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi kiểm tra:\n{ex.Message}", "Lỗi", 
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Thêm chức năng để chuyển đổi giữa thật và giả
        private void btnChuyenDoiMode_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Bạn có muốn thử kết nối thật không?\n\n" +
                "YES: Thử kết nối thật với database\n" +
                "NO: Tiếp tục dùng chế độ giả lập", 
                "Chuyển đổi chế độ", 
                MessageBoxButtons.YesNo, 
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                ThuKetNoiThat();
            }
        }

        // Phương thức thử kết nối thật
        private void ThuKetNoiThat()
        {
            try
            {
                if (sqlCon == null)
                {
                    sqlCon = new SqlConnection(strCon);
                }
                
                if (sqlCon.State == ConnectionState.Closed)
                {
                    sqlCon.Open();
                    
                    string serverVersion = sqlCon.ServerVersion;
                    string database = sqlCon.Database;
                    
                    MessageBox.Show($"Kết nối thật thành công!\nDatabase: {database}\nSQL Server Version: {serverVersion}", 
                                  "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    sqlCon.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Kết nối thật thất bại:\n{ex.Message}\n\nTiếp tục dùng chế độ giả lập.", 
                              "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // Giải phóng tài nguyên khi form đóng
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (sqlCon != null)
            {
                if (sqlCon.State == ConnectionState.Open)
                {
                    sqlCon.Close();
                }
                sqlCon.Dispose();
            }
        }
    }
}
