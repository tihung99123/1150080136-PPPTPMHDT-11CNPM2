﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LeQuocHung_1150080136
{
    public partial class Form1 : Form
    {
        // Kết nối và controls
        private SqlConnection sqlCon = null;
        // Thay đường dẫn tới file .mdf của bạn nếu cần
        private string strCon = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Administrator\source\repos\LeQuocHung_1150080136\LeQuocHung_1150080136\Database1.mdf;Integrated Security=True";

    private Button btnHienThi;
        private DataGridView dgvDanhSach;
    private SplitContainer split;
    // Các biến dùng cho thao tác dữ liệu
    private SqlDataAdapter adapter = null;
    private DataSet ds = null;
    private TextBox txtMaXB, txtTenXB, txtDiaChi;
    private Button btnThemDL, btnSua, btnXoa;
    // Tên bảng trong database (chỉnh nếu cần)
    private string tableName = "NhaXuatBan";

        public Form1()
        {
            InitializeComponent();

            // Tạo giao diện sử dụng SplitContainer để hiển thị toàn bộ và co giãn tốt
            // Tạo SplitContainer dưới dạng trường lớp để có thể điều chỉnh SplitterDistance sau khi Form đã load
            split = new SplitContainer();
            split.Dock = DockStyle.Fill;
            split.Orientation = Orientation.Vertical;
            // Đặt kích thước tối thiểu tạm thời nhỏ để tránh lỗi khi form chưa có kích thước thực
            split.Panel1MinSize = 50;
            split.Panel2MinSize = 50;
            // Đặt một giá trị tạm an toàn cho SplitterDistance; giá trị chính xác sẽ được điều chỉnh trong Form1_Load
            split.SplitterDistance = 300;
            this.Controls.Add(split);

            // Left panel: nút Hiển thị trên cùng và DataGridView chiếm phần còn lại
            Panel leftPanel = new Panel();
            leftPanel.Dock = DockStyle.Fill;
            split.Panel1.Controls.Add(leftPanel);

            FlowLayoutPanel topFlow = new FlowLayoutPanel();
            topFlow.Dock = DockStyle.Top;
            topFlow.Height = 50;
            topFlow.Padding = new Padding(10);
            leftPanel.Controls.Add(topFlow);

            btnHienThi = new Button();
            btnHienThi.Text = "Hiển thị danh sách";
            btnHienThi.AutoSize = true;
            btnHienThi.Click += btnHienThi_Click;
            topFlow.Controls.Add(btnHienThi);

            dgvDanhSach = new DataGridView();
            dgvDanhSach.Dock = DockStyle.Fill;
            dgvDanhSach.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvDanhSach.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvDanhSach.MultiSelect = false;
            leftPanel.Controls.Add(dgvDanhSach);

            // Right panel: GroupBox chứa form chỉnh sửa
            GroupBox grp = new GroupBox();
            grp.Text = "Chỉnh sửa thông tin";
            grp.Dock = DockStyle.Fill;
            split.Panel2.Controls.Add(grp);

            TableLayoutPanel tbl = new TableLayoutPanel();
            tbl.Dock = DockStyle.Top;
            tbl.ColumnCount = 2;
            tbl.RowCount = 4;
            // Không auto-size để tránh chiếm toàn bộ GroupBox và đẩy nút xuống ngoài màn hình
            tbl.AutoSize = false;
            tbl.Height = 130;
            tbl.Padding = new Padding(10);
            tbl.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 35));
            tbl.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 65));
            grp.Controls.Add(tbl);

            // Row 0: Mã NXB
            tbl.Controls.Add(new Label() { Text = "Mã NXB:", Anchor = AnchorStyles.Left, AutoSize = true }, 0, 0);
            txtMaXB = new TextBox() { Anchor = AnchorStyles.Left | AnchorStyles.Right, Width = 200 };
            tbl.Controls.Add(txtMaXB, 1, 0);

            // Row 1: Tên NXB
            tbl.Controls.Add(new Label() { Text = "Tên NXB:", Anchor = AnchorStyles.Left, AutoSize = true }, 0, 1);
            txtTenXB = new TextBox() { Anchor = AnchorStyles.Left | AnchorStyles.Right, Width = 200 };
            tbl.Controls.Add(txtTenXB, 1, 1);

            // Row 2: Địa chỉ
            tbl.Controls.Add(new Label() { Text = "Địa chỉ:", Anchor = AnchorStyles.Left, AutoSize = true }, 0, 2);
            txtDiaChi = new TextBox() { Anchor = AnchorStyles.Left | AnchorStyles.Right, Width = 200 };
            tbl.Controls.Add(txtDiaChi, 1, 2);

            // Buttons
            FlowLayoutPanel btnFlow = new FlowLayoutPanel();
            // đặt panel nút ở đáy GroupBox để luôn nhìn thấy các nút
            btnFlow.Dock = DockStyle.Bottom;
            btnFlow.Height = 60;
            btnFlow.Padding = new Padding(10);
            btnFlow.FlowDirection = FlowDirection.LeftToRight;
            btnFlow.WrapContents = false;
            btnFlow.AutoSize = false;
            btnFlow.Visible = true;
            grp.Controls.Add(btnFlow);

            btnThemDL = new Button() { Text = "Thêm dữ liệu", AutoSize = true, Width = 120, Height = 36 };
            btnThemDL.Click += btnThemDL_Click;
            btnFlow.Controls.Add(btnThemDL);

            btnSua = new Button() { Text = "Chỉnh sửa thông tin", AutoSize = true, Width = 140, Height = 36 };
            btnSua.Click += btnSua_Click;
            btnFlow.Controls.Add(btnSua);

            btnXoa = new Button() { Text = "Xóa dữ liệu", AutoSize = true, Width = 120, Height = 36 };
            btnXoa.Click += btnXoa_Click;
            btnFlow.Controls.Add(btnXoa);

            // Gắn sự kiện Load của Form và selection changed
            this.Load += Form1_Load;
            dgvDanhSach.SelectionChanged += dgvDanhSach_SelectionChanged;
        }

        // Mở kết nối
        private void MoKetNoi()
        {
            try
            {
                if (sqlCon == null)
                {
                    sqlCon = new SqlConnection(strCon);
                }
                if (sqlCon.State == ConnectionState.Closed)
                {
                    sqlCon.Open();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi mở kết nối:\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Đóng kết nối
        private void DongKetNoi()
        {
            try
            {
                if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                {
                    sqlCon.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi đóng kết nối:\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Xử lý nút hiển thị
        private void btnHienThi_Click(object sender, EventArgs e)
        {
            // Hiển thị dữ liệu (dùng cùng tableName class-level)
            try
            {
                MoKetNoi();
                string sql = $"SELECT * FROM {tableName}";
                SqlDataAdapter tmpAdapter = new SqlDataAdapter(sql, sqlCon);
                DataSet tmpDs = new DataSet();
                tmpAdapter.Fill(tmpDs, "tbl" + tableName);
                if (tmpDs.Tables.Count > 0)
                {
                    dgvDanhSach.DataSource = tmpDs.Tables[0];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải dữ liệu:\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DongKetNoi();
            }
        }

        // Xóa dữ liệu trên form (clear input controls)
        private void XoaDuLieuForm()
        {
            if (txtMaXB != null) txtMaXB.Text = string.Empty;
            if (txtTenXB != null) txtTenXB.Text = string.Empty;
            if (txtDiaChi != null) txtDiaChi.Text = string.Empty;
        }

        // Hiển thị dữ liệu lên DataGridView và khởi tạo adapter/dataset để có thể Update
        private void hienThiDuLieu()
        {
            try
            {
                MoKetNoi();
                string query = $"SELECT * FROM {tableName}";
                adapter = new SqlDataAdapter(query, sqlCon);
                SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
                ds = new DataSet();
                adapter.Fill(ds, "tbl" + tableName);
                if (ds.Tables.Count > 0)
                {
                    dgvDanhSach.DataSource = ds.Tables["tbl" + tableName];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi hiển thị dữ liệu:\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DongKetNoi();
            }
        }

        // Tạo bảng nếu chưa tồn tại (theo cấu trúc: XB PK, TenXB, DiaChi)
        private void EnsureTableExists()
        {
            try
            {
                MoKetNoi();
                string checkSql = $"IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[{tableName}]') AND type in (N'U')) BEGIN CREATE TABLE [dbo].[{tableName}] (XB NVARCHAR(50) PRIMARY KEY, TenXB NVARCHAR(200) NULL, DiaChi NVARCHAR(300) NULL) END";
                using (SqlCommand cmd = new SqlCommand(checkSql, sqlCon))
                {
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tạo kiểm tra bảng:\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DongKetNoi();
            }
        }

        private void dgvDanhSach_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvDanhSach.CurrentRow == null) return;
            try
            {
                var row = (dgvDanhSach.CurrentRow.DataBoundItem as DataRowView)?.Row;
                if (row != null)
                {
                    if (row.Table.Columns.Contains("XB")) txtMaXB.Text = row["XB"].ToString();
                    else if (row.Table.Columns.Contains("MaNXB")) txtMaXB.Text = row["MaNXB"].ToString();
                    if (row.Table.Columns.Contains("TenXB")) txtTenXB.Text = row["TenXB"].ToString();
                    if (row.Table.Columns.Contains("DiaChi")) txtDiaChi.Text = row["DiaChi"].ToString();
                }
            }
            catch { }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            // Cập nhật bằng lệnh parameterized
            if (string.IsNullOrWhiteSpace(txtMaXB.Text)) { MessageBox.Show("Mã NXB không được để trống."); return; }
            try
            {
                MoKetNoi();
                string updateSql = $"UPDATE {tableName} SET TenXB=@TenXB, DiaChi=@DiaChi WHERE XB=@XB";
                using (SqlCommand cmd = new SqlCommand(updateSql, sqlCon))
                {
                    cmd.Parameters.AddWithValue("@XB", txtMaXB.Text.Trim());
                    cmd.Parameters.AddWithValue("@TenXB", txtTenXB.Text.Trim());
                    cmd.Parameters.AddWithValue("@DiaChi", txtDiaChi.Text.Trim());
                    int affected = cmd.ExecuteNonQuery();
                    if (affected > 0) MessageBox.Show("Cập nhật thành công."); else MessageBox.Show("Không tìm thấy bản ghi để cập nhật.");
                }
                hienThiDuLieu();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi cập nhật:\n" + ex.Message);
            }
            finally { DongKetNoi(); }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaXB.Text)) { MessageBox.Show("Chọn Mã NXB để xóa."); return; }
            if (MessageBox.Show("Bạn có chắc muốn xóa bản ghi này?", "Xác nhận", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            try
            {
                MoKetNoi();
                string delSql = $"DELETE FROM {tableName} WHERE XB=@XB";
                using (SqlCommand cmd = new SqlCommand(delSql, sqlCon))
                {
                    cmd.Parameters.AddWithValue("@XB", txtMaXB.Text.Trim());
                    int affected = cmd.ExecuteNonQuery();
                    if (affected > 0) MessageBox.Show("Xóa thành công."); else MessageBox.Show("Không tìm thấy bản ghi để xóa.");
                }
                hienThiDuLieu();
                XoaDuLieuForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi xóa:\n" + ex.Message);
            }
            finally { DongKetNoi(); }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Ensure table exists before loading data
            EnsureTableExists();
            hienThiDuLieu();
            XoaDuLieuForm();
            // Điều chỉnh SplitterDistance an toàn sau khi Form đã có kích thước thực
            try
            {
                if (split != null)
                {
                    int clientW = this.ClientSize.Width;
                    // Desired minimum sizes for panels (can be adjusted)
                    int desiredMin1 = 250;
                    int desiredMin2 = 300;
                    // If sum of desired mins too large, reduce desiredMin2 to fit
                    if (desiredMin1 + desiredMin2 > clientW)
                    {
                        desiredMin2 = Math.Max(50, clientW - desiredMin1);
                    }
                    split.Panel1MinSize = desiredMin1;
                    split.Panel2MinSize = desiredMin2;

                    int max = clientW - split.Panel2MinSize;
                    int desired = (int)(clientW * 0.45);
                    if (desired < split.Panel1MinSize) desired = split.Panel1MinSize;
                    if (desired > max) desired = max;
                    // guard: ensure desired is within valid range
                    if (desired >= split.Panel1MinSize && desired <= max)
                    {
                        split.SplitterDistance = desired;
                    }
                    else
                    {
                        // fallback: set to min allowable
                        split.SplitterDistance = Math.Min(Math.Max(split.Panel1MinSize, 100), Math.Max(100, max));
                    }
                }
            }
            catch { }
        }

        private void btnThemDL_Click(object sender, EventArgs e)
        {
            if (ds == null || adapter == null)
            {
                MessageBox.Show("Dữ liệu chưa được nạp. Nhấn 'Hiển thị danh sách' hoặc load lại form.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                DataTable table = ds.Tables["tbl" + tableName];
                if (table == null)
                {
                    MessageBox.Show("Không tìm thấy bảng dữ liệu trong DataSet.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                DataRow row = table.NewRow();
                // Thay tên cột cho đúng với cấu trúc bảng trong database
                // Ví dụ: cột Mã NXB là "XB" theo snippet gốc
                if (table.Columns.Contains("XB")) row["XB"] = txtMaXB.Text.Trim();
                else if (table.Columns.Contains("MaNXB")) row["MaNXB"] = txtMaXB.Text.Trim();
                else if (table.Columns.Contains("Ma")) row["Ma"] = txtMaXB.Text.Trim();

                if (table.Columns.Contains("TenXB")) row["TenXB"] = txtTenXB.Text.Trim();
                else if (table.Columns.Contains("Ten")) row["Ten"] = txtTenXB.Text.Trim();

                if (table.Columns.Contains("DiaChi")) row["DiaChi"] = txtDiaChi.Text.Trim();
                else if (table.Columns.Contains("Dia")) row["Dia"] = txtDiaChi.Text.Trim();

                table.Rows.Add(row);
                MoKetNoi();
                int kq = adapter.Update(table);
                if (kq > 0)
                {
                    MessageBox.Show("Thêm dữ liệu thành công!");
                    hienThiDuLieu();
                    XoaDuLieuForm();
                }
                else
                {
                    MessageBox.Show("Thêm dữ liệu không thành công!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm dữ liệu:\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DongKetNoi();
            }
        }

        // Đóng kết nối khi form đóng
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            try
            {
                if (sqlCon != null)
                {
                    sqlCon.Dispose();
                    sqlCon = null;
                }
            }
            catch { }
        }
    }
}
