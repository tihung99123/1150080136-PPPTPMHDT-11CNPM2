﻿using System;                     
using System.Windows.Forms;       

namespace ApDung1  
{
	
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();  
		}

		// Hàm tính Ước số chung lớn nhất (USCLN) bằng thuật toán Euclid
		private int USCLN(int a, int b)
		{
			while (b != 0)          
			{
				int temp = a % b;  
				a = b;              
				b = temp;           
			}
			return a;               
		}

		// Hàm tính Bội số chung nhỏ nhất (BSCNN) 
		private int BSCNN(int a, int b)
		{
			return (a * b) / USCLN(a, b);
		}

		
		private void btnTim_Click(object sender, EventArgs e)
		{
			try
			{
				
				int a = int.Parse(txtA.Text.Trim());
				int b = int.Parse(txtB.Text.Trim());

				
				if (radUSCLN.Checked)
				{
					txtKetQua.Text = USCLN(a, b).ToString();
				}
				
				else if (radBSCNN.Checked)
				{
					txtKetQua.Text = BSCNN(a, b).ToString();
				}
				// Nếu chưa chọn radio nào thì thông báo
				else
				{
					MessageBox.Show("Vui lòng chọn USCLN hoặc BSCNN trước khi tính!",
									"Thông báo",
									MessageBoxButtons.OK,
									MessageBoxIcon.Warning);
				}
			}
			catch
			{
				
				MessageBox.Show("Vui lòng nhập số nguyên hợp lệ!");
			}
		}

		
		private void btnThoat_Click(object sender, EventArgs e)
		{
			DialogResult result = MessageBox.Show("Bạn có chắc muốn thoát?",
												  "Xác nhận",
												  MessageBoxButtons.YesNo,
												  MessageBoxIcon.Question);
			if (result == DialogResult.Yes)
			{
				this.Close();
			}
		}
	}
}
