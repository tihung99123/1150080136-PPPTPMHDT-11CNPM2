﻿namespace ApDung2
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.txtPassword = new System.Windows.Forms.TextBox();
			this.panel2 = new System.Windows.Forms.Panel();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.btn1 = new System.Windows.Forms.Button();
			this.btn2 = new System.Windows.Forms.Button();
			this.btn4 = new System.Windows.Forms.Button();
			this.btn5 = new System.Windows.Forms.Button();
			this.btn3 = new System.Windows.Forms.Button();
			this.btn7 = new System.Windows.Forms.Button();
			this.btn6 = new System.Windows.Forms.Button();
			this.btn8 = new System.Windows.Forms.Button();
			this.btnClear = new System.Windows.Forms.Button();
			this.btn9 = new System.Windows.Forms.Button();
			this.btnEnter = new System.Windows.Forms.Button();
			this.btnRing = new System.Windows.Forms.Button();
			this.dgvLog = new System.Windows.Forms.DataGridView();
			this.colDateTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.colGroup = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.colResult = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvLog)).BeginInit();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(20, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(87, 19);
			this.label1.TabIndex = 0;
			this.label1.Text = "Password:";
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.SystemColors.ActiveBorder;
			this.panel1.Controls.Add(this.txtPassword);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Location = new System.Drawing.Point(1, 1);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(562, 91);
			this.panel1.TabIndex = 1;
			// 
			// txtPassword
			// 
			this.txtPassword.Location = new System.Drawing.Point(174, 39);
			this.txtPassword.Name = "txtPassword";
			this.txtPassword.Size = new System.Drawing.Size(220, 20);
			this.txtPassword.TabIndex = 1;
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.btnRing);
			this.panel2.Controls.Add(this.btnEnter);
			this.panel2.Controls.Add(this.btn9);
			this.panel2.Controls.Add(this.btnClear);
			this.panel2.Controls.Add(this.btn8);
			this.panel2.Controls.Add(this.btn6);
			this.panel2.Controls.Add(this.btn7);
			this.panel2.Controls.Add(this.btn3);
			this.panel2.Controls.Add(this.btn5);
			this.panel2.Controls.Add(this.btn4);
			this.panel2.Controls.Add(this.btn2);
			this.panel2.Controls.Add(this.btn1);
			this.panel2.Controls.Add(this.label2);
			this.panel2.Location = new System.Drawing.Point(1, 98);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(562, 177);
			this.panel2.TabIndex = 2;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(21, -3);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(80, 19);
			this.label2.TabIndex = 0;
			this.label2.Text = "Keyboard";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.Location = new System.Drawing.Point(21, 278);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(86, 19);
			this.label3.TabIndex = 3;
			this.label3.Text = "Login Log";
			// 
			// btn1
			// 
			this.btn1.Location = new System.Drawing.Point(135, 30);
			this.btn1.Name = "btn1";
			this.btn1.Size = new System.Drawing.Size(49, 39);
			this.btn1.TabIndex = 1;
			this.btn1.Text = "1";
			this.btn1.UseVisualStyleBackColor = true;
			this.btn1.Click += new System.EventHandler(this.NumberButton_Click);
			// 
			// btn2
			// 
			this.btn2.Location = new System.Drawing.Point(190, 30);
			this.btn2.Name = "btn2";
			this.btn2.Size = new System.Drawing.Size(45, 39);
			this.btn2.TabIndex = 2;
			this.btn2.Text = "2";
			this.btn2.UseVisualStyleBackColor = true;
			this.btn2.Click += new System.EventHandler(this.NumberButton_Click);
			// 
			// btn4
			// 
			this.btn4.Location = new System.Drawing.Point(135, 75);
			this.btn4.Name = "btn4";
			this.btn4.Size = new System.Drawing.Size(49, 36);
			this.btn4.TabIndex = 3;
			this.btn4.Text = "4";
			this.btn4.UseVisualStyleBackColor = true;
			this.btn4.Click += new System.EventHandler(this.NumberButton_Click);
			// 
			// btn5
			// 
			this.btn5.Location = new System.Drawing.Point(190, 75);
			this.btn5.Name = "btn5";
			this.btn5.Size = new System.Drawing.Size(45, 36);
			this.btn5.TabIndex = 4;
			this.btn5.Text = "5";
			this.btn5.UseVisualStyleBackColor = true;
			this.btn5.Click += new System.EventHandler(this.NumberButton_Click);
			// 
			// btn3
			// 
			this.btn3.Location = new System.Drawing.Point(241, 30);
			this.btn3.Name = "btn3";
			this.btn3.Size = new System.Drawing.Size(46, 39);
			this.btn3.TabIndex = 5;
			this.btn3.Text = "3";
			this.btn3.UseVisualStyleBackColor = true;
			this.btn3.Click += new System.EventHandler(this.NumberButton_Click);
			// 
			// btn7
			// 
			this.btn7.Location = new System.Drawing.Point(135, 117);
			this.btn7.Name = "btn7";
			this.btn7.Size = new System.Drawing.Size(49, 34);
			this.btn7.TabIndex = 6;
			this.btn7.Text = "7";
			this.btn7.UseVisualStyleBackColor = true;
			this.btn7.Click += new System.EventHandler(this.NumberButton_Click);
			// 
			// btn6
			// 
			this.btn6.Location = new System.Drawing.Point(241, 75);
			this.btn6.Name = "btn6";
			this.btn6.Size = new System.Drawing.Size(46, 36);
			this.btn6.TabIndex = 7;
			this.btn6.Text = "6";
			this.btn6.UseVisualStyleBackColor = true;
			this.btn6.Click += new System.EventHandler(this.NumberButton_Click);
			// 
			// btn8
			// 
			this.btn8.Location = new System.Drawing.Point(190, 117);
			this.btn8.Name = "btn8";
			this.btn8.Size = new System.Drawing.Size(45, 34);
			this.btn8.TabIndex = 8;
			this.btn8.Text = "8";
			this.btn8.UseVisualStyleBackColor = true;
			this.btn8.Click += new System.EventHandler(this.NumberButton_Click);
			// 
			// btnClear
			// 
			this.btnClear.BackColor = System.Drawing.Color.Yellow;
			this.btnClear.Location = new System.Drawing.Point(319, 30);
			this.btnClear.Name = "btnClear";
			this.btnClear.Size = new System.Drawing.Size(75, 39);
			this.btnClear.TabIndex = 9;
			this.btnClear.Text = "Clear";
			this.btnClear.UseVisualStyleBackColor = false;
			this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
			// 
			// btn9
			// 
			this.btn9.Location = new System.Drawing.Point(241, 117);
			this.btn9.Name = "btn9";
			this.btn9.Size = new System.Drawing.Size(46, 34);
			this.btn9.TabIndex = 10;
			this.btn9.Text = "9";
			this.btn9.UseVisualStyleBackColor = true;
			this.btn9.Click += new System.EventHandler(this.NumberButton_Click);
			// 
			// btnEnter
			// 
			this.btnEnter.BackColor = System.Drawing.Color.LimeGreen;
			this.btnEnter.Location = new System.Drawing.Point(319, 75);
			this.btnEnter.Name = "btnEnter";
			this.btnEnter.Size = new System.Drawing.Size(75, 36);
			this.btnEnter.TabIndex = 11;
			this.btnEnter.Text = "Enter";
			this.btnEnter.UseVisualStyleBackColor = false;
			this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
			// 
			// btnRing
			// 
			this.btnRing.BackColor = System.Drawing.Color.Crimson;
			this.btnRing.Location = new System.Drawing.Point(319, 117);
			this.btnRing.Name = "btnRing";
			this.btnRing.Size = new System.Drawing.Size(75, 34);
			this.btnRing.TabIndex = 12;
			this.btnRing.Text = "Ring";
			this.btnRing.UseVisualStyleBackColor = false;
			this.btnRing.Click += new System.EventHandler(this.btnRing_Click);
			// 
			// dgvLog
			// 
			this.dgvLog.AllowUserToAddRows = false;
			this.dgvLog.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dgvLog.BackgroundColor = System.Drawing.SystemColors.Control;
			this.dgvLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgvLog.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colDateTime,
            this.colGroup,
            this.colResult});
			this.dgvLog.Location = new System.Drawing.Point(1, 300);
			this.dgvLog.Name = "dgvLog";
			this.dgvLog.ReadOnly = true;
			this.dgvLog.Size = new System.Drawing.Size(562, 124);
			this.dgvLog.TabIndex = 4;
			// 
			// colDateTime
			// 
			this.colDateTime.HeaderText = "Ngày giờ";
			this.colDateTime.Name = "colDateTime";
			this.colDateTime.ReadOnly = true;
			// 
			// colGroup
			// 
			this.colGroup.HeaderText = "Nhóm";
			this.colGroup.Name = "colGroup";
			this.colGroup.ReadOnly = true;
			// 
			// colResult
			// 
			this.colResult.HeaderText = "Kết quả";
			this.colResult.Name = "colResult";
			this.colResult.ReadOnly = true;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(562, 423);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.dgvLog);
			this.Name = "Form1";
			this.Text = "Form1";
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvLog)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.TextBox txtPassword;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button btnRing;
		private System.Windows.Forms.Button btnEnter;
		private System.Windows.Forms.Button btn9;
		private System.Windows.Forms.Button btnClear;
		private System.Windows.Forms.Button btn8;
		private System.Windows.Forms.Button btn6;
		private System.Windows.Forms.Button btn7;
		private System.Windows.Forms.Button btn3;
		private System.Windows.Forms.Button btn5;
		private System.Windows.Forms.Button btn4;
		private System.Windows.Forms.Button btn2;
		private System.Windows.Forms.Button btn1;
		private System.Windows.Forms.DataGridView dgvLog;
		private System.Windows.Forms.DataGridViewTextBoxColumn colDateTime;
		private System.Windows.Forms.DataGridViewTextBoxColumn colGroup;
		private System.Windows.Forms.DataGridViewTextBoxColumn colResult;
	}
}

