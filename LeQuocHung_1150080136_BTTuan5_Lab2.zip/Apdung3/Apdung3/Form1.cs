﻿using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace Apdung3
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();

			// Gán sự kiện Validating bằng code (nếu chưa gán trong Designer)
			this.txtUsername.Validating += new CancelEventHandler(txtUsername_Validating);
			this.txtPassword.Validating += new CancelEventHandler(txtPassword_Validating);
		}

		// Nút Đăng nhập
		private void btnLogin_Click(object sender, EventArgs e)
		{
			// ép gọi sự kiện Validating cho tất cả control
			if (ValidateChildren(ValidationConstraints.Enabled))
			{
				MessageBox.Show("Đăng nhập thành công!", "Thông báo",
								MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
		}

		// Kiểm tra Username
		private void txtUsername_Validating(object sender, CancelEventArgs e)
		{
			if (string.IsNullOrWhiteSpace(txtUsername.Text))
			{
				e.Cancel = true;
				err.SetError(txtUsername, "Username không được để trống!");
			}
			else
			{
				e.Cancel = false;
				err.SetError(txtUsername, null);
			}
		}

		// Kiểm tra Password
		private void txtPassword_Validating(object sender, CancelEventArgs e)
		{
			if (string.IsNullOrWhiteSpace(txtPassword.Text))
			{
				e.Cancel = true;
				err.SetError(txtPassword, "Password không được để trống!");
			}
			else
			{
				e.Cancel = false;
				err.SetError(txtPassword, null);
			}
		}
		private void btnExit_Click(object sender, EventArgs e)
		{
			DialogResult result = MessageBox.Show("Bạn có muốn thoát chương trình?",
												  "Thoát",
												  MessageBoxButtons.YesNo,
												  MessageBoxIcon.Question);
			if (result == DialogResult.Yes)
				this.Close();
		}
	}
}
