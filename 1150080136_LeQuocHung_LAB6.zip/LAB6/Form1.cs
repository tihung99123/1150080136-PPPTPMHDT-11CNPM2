﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace LAB6
{
    public partial class Form1 : Form
    {
        // Dùng |DataDirectory| để app chạy ổn khi build/release.
        // Đổi tên file .mdf nếu bạn đặt khác "Database1.mdf".
        private readonly string _strCon =
            @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True";

        private SqlConnection _sqlCon;

        public Form1()
        {
            InitializeComponent();
        }

        #region Kết nối
        private void MoKetNoi()
        {
            if (_sqlCon == null) _sqlCon = new SqlConnection(_strCon);
            if (_sqlCon.State == ConnectionState.Closed) _sqlCon.Open();
        }

        private void DongKetNoi()
        {
            if (_sqlCon != null && _sqlCon.State == ConnectionState.Open) _sqlCon.Close();
        }
        #endregion

        #region Load/Hiển thị dữ liệu
        // TH1: Hiển thị danh sách NXB (ưu tiên Stored Procedure)
        private void HienThiDanhSachNXB()
        {
            try
            {
                MoKetNoi();
                using (SqlCommand cmd = new SqlCommand("hienThiNXB", _sqlCon))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        lsvDanhSach.BeginUpdate();
                        lsvDanhSach.Items.Clear();

                        while (reader.Read())
                        {
                            string ma = reader.IsDBNull(0) ? "" : reader.GetString(0).Trim();
                            string ten = reader.IsDBNull(1) ? "" : reader.GetString(1);
                            string diachi = reader.IsDBNull(2) ? "" : reader.GetString(2);

                            var lvi = new ListViewItem(ma);
                            lvi.SubItems.Add(ten);
                            lvi.SubItems.Add(diachi);
                            lsvDanhSach.Items.Add(lvi);
                        }

                        lsvDanhSach.EndUpdate();
                    }
                }
            }
            catch (SqlException)
            {
                // Fallback: nếu chưa tạo SP, dùng SELECT để bạn vẫn test được
                try
                {
                    using (SqlCommand cmd = new SqlCommand(
                        "SELECT NXB, TenNXB, DiaChi FROM dbo.NhaXuatBan ORDER BY NXB", _sqlCon))
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        lsvDanhSach.BeginUpdate();
                        lsvDanhSach.Items.Clear();

                        while (reader.Read())
                        {
                            string ma = reader.IsDBNull(0) ? "" : reader.GetString(0).Trim();
                            string ten = reader.IsDBNull(1) ? "" : reader.GetString(1);
                            string diachi = reader.IsDBNull(2) ? "" : reader.GetString(2);

                            var lvi = new ListViewItem(ma);
                            lvi.SubItems.Add(ten);
                            lvi.SubItems.Add(diachi);
                            lsvDanhSach.Items.Add(lvi);
                        }

                        lsvDanhSach.EndUpdate();
                    }
                }
                catch (Exception ex2)
                {
                    MessageBox.Show("Lỗi khi hiển thị dữ liệu: " + ex2.Message,
                        "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi hiển thị dữ liệu: " + ex.Message,
                    "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DongKetNoi();
            }
        }

        // Hiển thị chi tiết 1 NXB theo mã (ưu tiên Stored Procedure)
        private void HienThiThongTinNXBTheoMa(string maNXB)
        {
            if (string.IsNullOrWhiteSpace(maNXB)) return;

            try
            {
                MoKetNoi();

                // Ưu tiên SP
                using (SqlCommand cmd = new SqlCommand("hienThiChiTietNXB", _sqlCon))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@maXB", SqlDbType.Char, 10).Value = maNXB;

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        txtMaNXB.Text = txtTenNXB.Text = txtDiaChi.Text = "";
                        if (reader.Read())
                        {
                            txtMaNXB.Text = reader.IsDBNull(0) ? "" : reader.GetString(0).Trim();
                            txtTenNXB.Text = reader.IsDBNull(1) ? "" : reader.GetString(1);
                            txtDiaChi.Text = reader.IsDBNull(2) ? "" : reader.GetString(2);
                        }
                    }
                }
            }
            catch (SqlException)
            {
                // Fallback SELECT
                try
                {
                    using (SqlCommand cmd = new SqlCommand(
                        "SELECT NXB, TenNXB, DiaChi FROM dbo.NhaXuatBan WHERE RTRIM(NXB)=RTRIM(@ma)", _sqlCon))
                    {
                        cmd.Parameters.Add("@ma", SqlDbType.Char, 10).Value = maNXB;

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            txtMaNXB.Text = txtTenNXB.Text = txtDiaChi.Text = "";
                            if (reader.Read())
                            {
                                txtMaNXB.Text = reader.IsDBNull(0) ? "" : reader.GetString(0).Trim();
                                txtTenNXB.Text = reader.IsDBNull(1) ? "" : reader.GetString(1);
                                txtDiaChi.Text = reader.IsDBNull(2) ? "" : reader.GetString(2);
                            }
                        }
                    }
                }
                catch (Exception ex2)
                {
                    MessageBox.Show("Lỗi khi lấy chi tiết NXB: " + ex2.Message,
                        "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi lấy chi tiết NXB: " + ex.Message,
                    "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DongKetNoi();
            }
        }
        #endregion

        #region Sự kiện form & control
        private void Form1_Load(object sender, EventArgs e)
        {
            HienThiDanhSachNXB();
            txtMaNXB.Focus();
        }

        private void lsvDanhSach_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lsvDanhSach.SelectedItems.Count == 0) return;
            string ma = lsvDanhSach.SelectedItems[0].SubItems[0].Text;
            HienThiThongTinNXBTheoMa(ma);
        }
        #endregion

        #region TH2: Thêm dữ liệu
        private void btnThem_Click(object sender, EventArgs e)
        {
            string ma = txtMaNXB.Text.Trim();
            string ten = txtTenNXB.Text.Trim();
            string diachi = txtDiaChi.Text.Trim();

            if (string.IsNullOrWhiteSpace(ma) || string.IsNullOrWhiteSpace(ten))
            {
                MessageBox.Show("Mã NXB và Tên NXB không được để trống!",
                    "Thiếu dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtMaNXB.Focus();
                return;
            }

            try
            {
                MoKetNoi();

                using (SqlCommand cmd = new SqlCommand("ThemDuLieu", _sqlCon))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@maXB", SqlDbType.Char, 10).Value = ma;
                    cmd.Parameters.Add("@tenXB", SqlDbType.NVarChar, 100).Value = ten;
                    cmd.Parameters.Add("@diaChi", SqlDbType.NVarChar, 500).Value = (object)diachi ?? DBNull.Value;

                    var ret = cmd.Parameters.Add("@RET", SqlDbType.Int);
                    ret.Direction = ParameterDirection.ReturnValue;

                    cmd.ExecuteNonQuery();

                    int result = (ret.Value == DBNull.Value) ? 0 : (int)ret.Value;
                    if (result == -1)
                    {
                        MessageBox.Show("Mã NXB đã tồn tại. Vui lòng nhập mã khác!",
                            "Trùng khóa", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txtMaNXB.Focus();
                        return;
                    }

                    MessageBox.Show("Thêm dữ liệu thành công!", "OK",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);

                    HienThiDanhSachNXB();
                    ClearForm();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm dữ liệu: " + ex.Message,
                    "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DongKetNoi();
            }
        }
        #endregion

        #region TH3: Sửa dữ liệu
        private void btnSua_Click(object sender, EventArgs e)
        {
            string ma = txtMaNXB.Text.Trim();
            string ten = txtTenNXB.Text.Trim();
            string diachi = txtDiaChi.Text.Trim();

            if (string.IsNullOrWhiteSpace(ma) || string.IsNullOrWhiteSpace(ten))
            {
                MessageBox.Show("Mã NXB và Tên NXB không được để trống!",
                    "Thiếu dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtMaNXB.Focus();
                return;
            }

            try
            {
                MoKetNoi();

                using (SqlCommand cmd = new SqlCommand("SuaDuLieu", _sqlCon))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@maXB", SqlDbType.Char, 10).Value = ma;
                    cmd.Parameters.Add("@tenXB", SqlDbType.NVarChar, 100).Value = ten;
                    cmd.Parameters.Add("@diaChi", SqlDbType.NVarChar, 500).Value = (object)diachi ?? DBNull.Value;

                    var ret = cmd.Parameters.Add("@RET", SqlDbType.Int);
                    ret.Direction = ParameterDirection.ReturnValue;

                    cmd.ExecuteNonQuery();
                    int result = (ret.Value == DBNull.Value) ? 0 : (int)ret.Value;

                    if (result == -1)
                    {
                        MessageBox.Show("Không tìm thấy Mã NXB để sửa!",
                            "Không tồn tại", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    MessageBox.Show("Sửa dữ liệu thành công!", "OK",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);

                    HienThiDanhSachNXB();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi sửa dữ liệu: " + ex.Message,
                    "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DongKetNoi();
            }
        }
        #endregion

        #region TH4: Xóa dữ liệu
        private void btnXoa_Click(object sender, EventArgs e)
        {
            string ma = txtMaNXB.Text.Trim();
            if (string.IsNullOrWhiteSpace(ma))
            {
                MessageBox.Show("Vui lòng chọn hoặc nhập Mã NXB cần xóa!",
                    "Thiếu dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show($"Bạn có chắc muốn xóa NXB '{ma}'?",
                                "Xác nhận xóa", MessageBoxButtons.YesNo,
                                MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            try
            {
                MoKetNoi();

                using (SqlCommand cmd = new SqlCommand("XoaDuLieu", _sqlCon))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@maXB", SqlDbType.Char, 10).Value = ma;

                    var ret = cmd.Parameters.Add("@RET", SqlDbType.Int);
                    ret.Direction = ParameterDirection.ReturnValue;

                    cmd.ExecuteNonQuery();
                    int result = (ret.Value == DBNull.Value) ? 0 : (int)ret.Value;

                    if (result == -1)
                    {
                        MessageBox.Show("Không tìm thấy Mã NXB để xóa!",
                            "Không tồn tại", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                    if (result == -2)
                    {
                        MessageBox.Show("NXB đang được tham chiếu trong bảng Sách. Không thể xóa!",
                            "Ràng buộc dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    MessageBox.Show("Xóa dữ liệu thành công!", "OK",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);

                    HienThiDanhSachNXB();
                    ClearForm();
                }
            }
            catch (SqlException exFk)
            {
                // Nếu DB có FK NO ACTION mà chưa kiểm tra trước, vào đây
                MessageBox.Show("Không thể xóa do ràng buộc dữ liệu (FK). Chi tiết: " + exFk.Message,
                    "Lỗi SQL", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi xóa dữ liệu: " + ex.Message,
                    "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DongKetNoi();
            }
        }
        #endregion

        #region Tiện ích & nút phụ
        private void btnReload_Click(object sender, EventArgs e)
        {
            HienThiDanhSachNXB();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void ClearForm()
        {
            txtMaNXB.Clear();
            txtTenNXB.Clear();
            txtDiaChi.Clear();
            txtMaNXB.Focus();
            lsvDanhSach.SelectedItems.Clear();
        }

        // Nếu Designer có gán event này thì để trống cũng không sao
        private void label5_Click(object sender, EventArgs e) { }
        #endregion
    }
}
